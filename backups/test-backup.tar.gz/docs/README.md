# QuantBot - Advanced Trading Simulation & CA Monitoring Bot

A sophisticated Telegram bot that provides PNL simulation for trading strategies and real-time CA (Contract Address) monitoring using Helius WebSockets.

## 🚀 Features

### 📊 **PNL Simulation**

- Multi-chain support: Solana, Ethereum, BSC, Base
- Hybrid candle fetching (5m recent + 1h historical)
- Customizable take-profit strategies
- Configurable stop-loss (initial + trailing)
- Detailed simulation events and performance metrics
- CSV caching for efficient data management

### 🎯 **Real-Time CA Monitoring**

- Automatic CA drop detection in chat messages
- Real-time price monitoring via Helius WebSockets
- Profit target alerts (2x, 5x, 10x, etc.)
- Stop-loss notifications
- **Ichimoku Cloud Analysis** with technical signals
- Hourly performance summaries
- Multi-chain CA tracking

### 💾 **Persistent Storage**

- SQLite database for simulation history
- Custom strategy management
- CA tracking and performance data
- Alert history and price updates

## 🔧 Setup

### Prerequisites

- Node.js 18+
- Telegram Bot Token
- Birdeye API Key
- Helius API Key (for CA monitoring)

### Installation

```bash
git clone <repository>
cd quantBot
npm install
```

### Environment Variables

Create a `.env` file:

```env
BOT_TOKEN=your_telegram_bot_token_here
BIRDEYE_API_KEY=your_birdeye_api_key_here
HELIUS_API_KEY=your_helius_api_key_here
TELEGRAM_DEFAULT_CHAT=-1002523160967
```

### Running the Bot

```bash
npm start
```

## 📱 Commands

### `/backtest`

Start a new PNL simulation:

1. Paste token address (Solana or EVM)
2. Select chain (for EVM addresses)
3. Enter start datetime (ISO format)
4. Choose take-profit strategy
5. Configure stop-loss settings

### `/repeat`

Repeat a previous simulation with new strategy:

- Lists recent simulations
- Select by number or "last"
- Reuses token and timeframe

### `/strategy`

Manage custom trading strategies:

- `/strategy` - List all strategies
- `/strategy save <name> <description> <strategy> <stop_loss>` - Save strategy
- `/strategy use <name>` - Load strategy for next backtest
- `/strategy delete <name>` - Delete strategy

### `/cancel`

Cancel current simulation session

### `/extract`

Extract CA drops from HTML chat messages and save to database:

- Processes all HTML files in the `messages/` folder
- Extracts token addresses with timestamps
- Fetches metadata for each token
- Saves to database for analysis

### `/analysis`

Run comprehensive historical analysis on all CA drops:

- Calculates success rates and performance metrics
- Analyzes performance by time periods and chains
- Generates strategy recommendations
- Provides detailed performance insights

### `/ichimoku`

Start Ichimoku Cloud analysis for a token:

1. Paste token address (Solana or EVM)
2. Select chain (for EVM addresses)
3. Bot fetches 52 historical 5-minute candles from Birdeye
4. Calculates Ichimoku Cloud components
5. Starts real-time price monitoring with leading span alerts

### `/broadcast <message>`

Send message to default chat (admin only)

## 🎯 CA Monitoring

The bot automatically detects CA drops in chat messages containing:

- Token addresses (Solana or EVM format)
- Trading keywords: "ca", "contract", "address", "buy", "pump", "moon", "gem", "call"

### Real-Time Alerts

- **🎯 Profit Targets**: Notifications when tokens hit 2x, 5x, 10x, etc.
- **🛑 Stop Loss**: Alerts when stop-loss is triggered
- **📊 Ichimoku Cloud Signals**: Technical analysis alerts
- **📊 Hourly Summaries**: Performance reports every hour

### 📈 Ichimoku Cloud Analysis

The bot includes advanced Ichimoku Cloud technical analysis for CA monitoring:

#### **Ichimoku Components**

- **Tenkan-sen (Conversion Line)**: 9-period high/low average
- **Kijun-sen (Base Line)**: 26-period high/low average  
- **Senkou Span A**: (Tenkan + Kijun) / 2, plotted 26 periods ahead
- **Senkou Span B**: 52-period high/low average, plotted 26 periods ahead
- **Chikou Span**: Current close, plotted 26 periods behind

#### **Trading Signals**

- **🟢 Tenkan-Kijun Cross**: Momentum shift when Tenkan crosses Kijun
- **🔥 Cloud Cross**: Strong trend change when price crosses cloud
- **⚡ Cloud Exit**: Price exiting cloud indicates trend continuation
- **💡 Momentum Shift**: Cloud thickness changes indicate strength changes

#### **Signal Strength**

- **Strong**: Thick cloud (>5% of price) or large Tenkan-Kijun distance (>2%)
- **Medium**: Moderate cloud thickness (2-5%) or medium distance (1-2%)
- **Weak**: Thin cloud (<2%) or small distance (<1%)

#### **Alert Format**

```text
🟢 Ichimoku Signal Detected!

🪙 Token Name (SYMBOL)
📊 Signal: Tenkan crossed above Kijun - Bullish momentum shift
💰 Price: $0.00012345
💪 Strength: ⚡ MEDIUM

📊 Ichimoku Analysis:
• Price: $0.00012345 (above cloud)
• Tenkan: $0.00012000
• Kijun: $0.00011800
• Cloud: $0.00011500 - $0.00012500
• Thickness: 8.3%
• Trend: 🟢 Bullish
```

## 📊 Historical Analysis

The bot includes comprehensive historical analysis capabilities for analyzing past CA drops:

### **Analysis Features**

- **Performance Metrics**: Success rates, average PNL, win/loss ratios
- **Time-based Analysis**: Performance by 24h, 7d, 30d, and older periods
- **Chain Analysis**: Success rates and performance by blockchain
- **Strategy Recommendations**: AI-generated suggestions based on historical data
- **Best/Worst Performers**: Identification of top and bottom performing tokens

### **Analysis Report Example**

```text
📊 Historical CA Analysis Report

📈 Overall Performance:
• Total CAs Analyzed: 150
• Success Rate: 42.7%
• Average PNL: 1.23x
• Profitable: 64 (42.7%)
• Losses: 86 (57.3%)

⏰ Performance by Time Period:
• Last 24h: 12 CAs, 58.3% success
• Last 7d: 45 CAs, 44.4% success
• Last 30d: 78 CAs, 41.0% success
• Older: 15 CAs, 33.3% success

🔗 Performance by Chain:
◎ SOLANA: 89 CAs, 45.2% success
🟡 BSC: 35 CAs, 37.1% success
⟠ ETHEREUM: 26 CAs, 38.5% success

🏆 Best Performer:
• TokenName (SYMBOL)
• PNL: 8.45x
• Chain: SOLANA

💡 Strategy Recommendations:
🔴 SUCCESS RATE: Low success rate (42.7%). Consider more conservative entry strategies.
   💡 Implement stricter token filtering or wait for better market conditions.
```

### **Usage Workflow**

1. **Extract Data**: `/extract` - Process HTML chat messages
2. **Run Analysis**: `/analysis` - Generate comprehensive report
3. **Review Results**: Analyze performance patterns and recommendations
4. **Optimize Strategy**: Use insights to improve future CA selection

### **Data Sources**

- **Chat Messages**: HTML files from Telegram chat exports
- **Current Prices**: Real-time data from Birdeye API
- **Historical Data**: Stored in SQLite database
- **Performance Tracking**: Continuous monitoring of CA performance

### Supported Chains

- **◎ Solana** - Default for Solana addresses
- **⟠ Ethereum** - EVM chain (eth/ethereum)
- **🟡 Binance Smart Chain** - EVM chain (bsc/binance)
- **🔵 Base** - EVM chain (base)

## 📈 Strategy Format

### Take-Profit Strategy

```text
Simple: 50@2x,30@5x,20@10x
JSON: [{"percent":0.5,"target":2},{"percent":0.3,"target":5}]
Default: yes
```

### Stop-Loss Configuration

```text
Format: initial: -30%, trailing: 50%
Examples:
- initial: -20%, trailing: 30%
- initial: -50%, trailing: 100%
- initial: -30%, trailing: none
- default
```

## 🗄️ Database Schema

### Tables

- `strategies` - Custom trading strategies
- `simulation_runs` - Historical simulation results
- `simulation_events` - Detailed simulation events
- `ca_tracking` - Active CA monitoring entries
- `price_updates` - Real-time price data
- `alerts_sent` - Alert history

## 🔌 API Integration

### Birdeye API

- Token metadata fetching
- OHLCV candle data
- Multi-chain support

### Helius WebSockets

- Real-time price updates
- Automatic reconnection
- Efficient subscription management

## 📊 Performance Features

### Caching System

- CSV-based OHLCV caching
- 24-hour cache expiry
- Intelligent cache extension
- Reduced API calls

### Monitoring Efficiency

- WebSocket-based real-time updates
- Smart alert deduplication
- Batch processing for summaries
- Memory-efficient data structures

## 🛠️ Development

### Project Structure

```text
src/
├── bot.ts              # Main bot logic
├── candles.ts          # OHLCV data fetching
├── simulate.ts         # PNL simulation engine
├── database.ts         # Database operations
├── helius-monitor.ts   # Real-time monitoring
└── .env               # Environment variables
```

### Key Dependencies

- `telegraf` - Telegram Bot API
- `axios` - HTTP requests
- `luxon` - Date/time handling
- `sqlite3` - Database
- `ws` - WebSocket client

## 🚨 Error Handling

- Graceful API failure handling
- Automatic WebSocket reconnection
- Database transaction safety
- User-friendly error messages
- Comprehensive logging

## 📝 License

ISC License - See LICENSE file for details
