/**
 * Begin Command Handler
 * =====================
 * Handles the /begin command for welcoming new users and showing available commands.
 */

import { Context } from 'telegraf';
import { BaseCommandHandler, Session } from './interfaces/CommandHandler';

export class BeginCommandHandler extends BaseCommandHandler {
  readonly command = 'begin';
  
  async execute(ctx: Context, session?: Session): Promise<void> {
    const welcomeMessage = `🤖 **Welcome to QuantBot!**

I'm your advanced trading simulation and CA monitoring assistant.

**📊 Core Features:**
• Backtest trading strategies on historical data
• Monitor contract addresses (CA) in real-time
• Analyze caller performance and token history
• Ichimoku Cloud technical analysis
• Multi-chain support (Solana, Ethereum, BSC, Base, Arbitrum)

**🚀 Quick Start:**
Use \`/backtest\` to simulate a trading strategy on any token.

**📱 Available Commands:**
Use \`/options\` to see all available commands.

**💡 Tip:** Just paste a token address to start tracking it automatically!`;

    await ctx.reply(welcomeMessage, { parse_mode: 'Markdown' });
  }
}

