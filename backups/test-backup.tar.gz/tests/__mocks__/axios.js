const axios = {
  get: jest.fn()
};

module.exports = axios;
module.exports.default = axios;
