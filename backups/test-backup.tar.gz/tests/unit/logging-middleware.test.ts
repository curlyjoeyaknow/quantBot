/**
 * Logging Middleware Tests
 * ========================
 * Tests for logging middleware functionality
 */

import { createRequestId, logRequest, logResponse, logError, logPerformance } from '../../src/utils/logging-middleware';
import { logger } from '../../src/utils/logger';

// Mock logger
jest.mock('../../src/utils/logger', () => ({
  logger: {
    error: jest.fn(),
    warn: jest.fn(),
    info: jest.fn(),
    debug: jest.fn(),
  },
}));

describe('Logging Middleware', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('createRequestId', () => {
    it('should create a unique request ID', () => {
      const id1 = createRequestId();
      const id2 = createRequestId();

      expect(id1).toBeDefined();
      expect(id2).toBeDefined();
      expect(id1).not.toBe(id2);
      expect(typeof id1).toBe('string');
      expect(id1.length).toBeGreaterThan(0);
    });
  });

  describe('logRequest', () => {
    it('should log request information', () => {
      const context = {
        method: 'GET',
        path: '/test',
        requestId: 'req-123',
        ip: '127.0.0.1',
        userAgent: 'test-agent',
      };

      logRequest(context);

      expect(logger.info).toHaveBeenCalledWith('Incoming request', {
        method: 'GET',
        path: '/test',
        requestId: 'req-123',
        ip: '127.0.0.1',
        userAgent: 'test-agent',
      });
    });
  });

  describe('logResponse', () => {
    it('should log successful response as info', () => {
      const context = {
        method: 'GET',
        path: '/test',
        statusCode: 200,
        duration: 100,
        requestId: 'req-123',
      };

      logResponse(context);

      expect(logger.info).toHaveBeenCalledWith('Request completed', {
        method: 'GET',
        path: '/test',
        statusCode: 200,
        duration: 100,
        requestId: 'req-123',
      });
    });

    it('should log error response as warn', () => {
      const context = {
        method: 'GET',
        path: '/test',
        statusCode: 404,
        duration: 50,
        requestId: 'req-123',
      };

      logResponse(context);

      expect(logger.warn).toHaveBeenCalledWith('Request completed', {
        method: 'GET',
        path: '/test',
        statusCode: 404,
        duration: 50,
        requestId: 'req-123',
      });
    });
  });

  describe('logError', () => {
    it('should log error with context', () => {
      const error = new Error('Test error');
      const context = {
        method: 'POST',
        path: '/api/test',
        requestId: 'req-123',
        statusCode: 500,
      };

      logError(error, context);

      expect(logger.error).toHaveBeenCalledWith('Request error', error, {
        method: 'POST',
        path: '/api/test',
        requestId: 'req-123',
        statusCode: 500,
      });
    });
  });

  describe('logPerformance', () => {
    it('should log performance metrics for successful operation', async () => {
      const fn = jest.fn().mockResolvedValue('result');
      const wrapped = logPerformance(fn, 'test-operation', { userId: 123 });

      const result = await wrapped('arg1', 'arg2');

      expect(result).toBe('result');
      expect(fn).toHaveBeenCalledWith('arg1', 'arg2');
      expect(logger.debug).toHaveBeenCalledWith(
        'Starting test-operation',
        expect.objectContaining({ userId: 123 })
      );
      expect(logger.debug).toHaveBeenCalledWith(
        'Completed test-operation',
        expect.objectContaining({ success: true, duration: expect.any(Number) })
      );
    });

    it('should log error for failed operation', async () => {
      const error = new Error('Operation failed');
      const fn = jest.fn().mockRejectedValue(error);
      const wrapped = logPerformance(fn, 'test-operation');

      await expect(wrapped()).rejects.toThrow('Operation failed');

      expect(logger.error).toHaveBeenCalledWith(
        'Failed test-operation',
        error,
        expect.objectContaining({ success: false, duration: expect.any(Number) })
      );
    });
  });
});

