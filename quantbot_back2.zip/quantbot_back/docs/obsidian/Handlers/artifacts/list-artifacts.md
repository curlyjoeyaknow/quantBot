# list-artifacts Handler

## Overview

Lists all artifacts with optional filtering.

## Location

`packages/cli/src/handlers/artifacts/list-artifacts.ts`

## Handler Function

`listArtifactsHandler`

## Parameters

- `format` (optional): Output format (`json`, `table`) - default: `table`
- `limit` (optional): Limit number of results
- `tag` (optional): Filter by tag

## Returns

```typescript
{
  artifacts: Artifact[];
  total: number;
}
```

## Related

- [[get-artifact]] - Get specific artifact
- [[tag-artifact]] - Tag artifact

