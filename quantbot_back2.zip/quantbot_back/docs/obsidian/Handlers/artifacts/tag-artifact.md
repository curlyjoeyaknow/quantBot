# tag-artifact Handler

## Overview

Tags an artifact with metadata.

## Location

`packages/cli/src/handlers/artifacts/tag-artifact.ts`

## Handler Function

`tagArtifactHandler`

## Parameters

- `id` (required): Artifact ID
- `tag` (required): Tag name
- `value` (optional): Tag value

## Returns

```typescript
{
  success: boolean;
  artifactId: string;
  tag: string;
}
```

## Related

- [[get-artifact]] - Get artifact
- [[list-artifacts]] - List artifacts

