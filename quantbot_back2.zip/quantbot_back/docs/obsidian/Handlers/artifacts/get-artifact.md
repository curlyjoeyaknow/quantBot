# get-artifact Handler

## Overview

Retrieves artifact by ID and version (or latest if version not specified).

## Location

`packages/cli/src/handlers/artifacts/get-artifact.ts`

## Handler Function

`getArtifactHandler`

## Status

⚠️ **TODO**: Implementation pending

## Parameters

- `id` (required): Artifact ID
- `version` (optional): Artifact version (defaults to latest)

## Returns

```typescript
{
  artifact: Artifact | null;
  found: boolean;
}
```

## Related

- [[list-artifacts]] - List all artifacts
- [[tag-artifact]] - Tag artifact

